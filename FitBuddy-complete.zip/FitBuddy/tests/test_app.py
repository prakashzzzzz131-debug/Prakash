import os
os.environ["AI_MOCK_MODE"] = "true"
os.environ["DATABASE_URL"] = "sqlite:///./test_fitbuddy.db"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_home():
    r = client.get("/")
    assert r.status_code == 200
    assert "Generate 7-Day Plan" in r.text

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_generate_and_feedback():
    r = client.post("/generate-workout", data={
        "username": "Test User", "user_id": "test001", "age": "30",
        "weight": "70", "goal": "muscle gain", "intensity": "medium"
    })
    assert r.status_code == 200
    assert "7-day workout plan" in r.text

    r = client.post("/submit-feedback", data={
        "user_id": "test001", "feedback": "Add more cardio and one rest day."
    })
    assert r.status_code == 200
    assert "updated" in r.text.lower()
