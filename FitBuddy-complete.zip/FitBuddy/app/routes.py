from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.database_crud import delete_user, get_all_users, get_latest_plan, get_user, save_plan, save_user, update_plan
from app.schemas import FeedbackRequest, UserInput
from app.services.gemini_service import generate_nutrition_tip_with_flash, generate_workout_gemini, update_workout_plan

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

def render_result(request: Request, user, plan, message=None):
    return templates.TemplateResponse(
        request=request,
        name="result.html",
        context={
            "user": user,
            "plan": plan,
            "message": message,
        },
    )

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})

@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    username: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        data = UserInput(username=username, user_id=user_id, age=age, weight=weight, goal=goal, intensity=intensity)
        user = save_user(db, data)
        workout = generate_workout_gemini(user.username, user.age, user.weight, user.goal, user.intensity)
        tip = generate_nutrition_tip_with_flash(user.goal)
        plan = save_plan(db, user, workout, tip)
        return render_result(request, user, plan)
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"error": f"Could not generate the plan: {exc}"},
            status_code=500,
        )

@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        data = FeedbackRequest(user_id=user_id, feedback=feedback)
        user = get_user(db, data.user_id)
        plan = get_latest_plan(db, data.user_id)
        if not user or not plan:
            raise HTTPException(status_code=404, detail="User or plan not found.")
        updated = update_workout_plan(plan.original_plan, data.feedback, user.goal, user.intensity)
        update_plan(db, plan, updated, data.feedback)
        return render_result(request, user, plan, "Your plan was updated using the feedback.")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not update plan: {exc}") from exc

def check_admin(token: str | None):
    configured = get_settings().admin_token
    if configured and token != configured:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid admin token.")

@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, token: str | None = None, db: Session = Depends(get_db)):
    check_admin(token)
    users = get_all_users(db)
    return templates.TemplateResponse(
        request=request,
        name="all_users.html",
        context={"users": users, "admin_token": token or ""},
    )

@router.post("/admin/delete/{user_id}")
def admin_delete_user(user_id: str, token: str | None = Form(None), db: Session = Depends(get_db)):
    check_admin(token)
    if not delete_user(db, user_id):
        raise HTTPException(status_code=404, detail="User not found.")
    return RedirectResponse(url="/view-all-users", status_code=303)

@router.get("/health")
def health():
    return {"status": "ok", "service": "fitbuddy"}

@router.get("/api/users")
def api_users(token: str | None = None, db: Session = Depends(get_db)):
    check_admin(token)
    return [
        {
            "user_id": u.user_id,
            "username": u.username,
            "age": u.age,
            "weight": u.weight,
            "goal": u.goal,
            "intensity": u.intensity,
            "plans": [
                {
                    "id": p.id,
                    "original_plan": p.original_plan,
                    "updated_plan": p.updated_plan,
                    "feedback": p.feedback,
                    "nutrition_tip": p.nutrition_tip,
                }
                for p in u.plans
            ],
        }
        for u in get_all_users(db)
    ]

@router.get("/api/users/{user_id}")
def api_user(user_id: str, token: str | None = None, db: Session = Depends(get_db)):
    check_admin(token)
    user = get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")
    return {
        "user_id": user.user_id,
        "username": user.username,
        "age": user.age,
        "weight": user.weight,
        "goal": user.goal,
        "intensity": user.intensity,
        "plans": [
            {
                "id": p.id,
                "original_plan": p.original_plan,
                "updated_plan": p.updated_plan,
                "feedback": p.feedback,
                "nutrition_tip": p.nutrition_tip,
            }
            for p in user.plans
        ],
    }
