from __future__ import annotations

from pydantic import BaseModel, Field
from app.config import get_settings

class Exercise(BaseModel):
    name: str
    sets: str = ""
    reps_or_duration: str
    rest: str
    notes: str = ""

class WorkoutDay(BaseModel):
    day: str
    focus: str
    warmup: str
    exercises: list[Exercise]
    cooldown: str

class WorkoutPlan(BaseModel):
    title: str
    safety_note: str
    days: list[WorkoutDay] = Field(min_length=7, max_length=7)

class GeminiService:
    def __init__(self) -> None:
        self.settings = get_settings()
        self.client = None
        if self.settings.google_api_key and not self.settings.ai_mock_mode:
            from google import genai
            self.client = genai.Client(api_key=self.settings.google_api_key)

    def _generate(self, model: str, prompt: str, schema: type[BaseModel]) -> BaseModel:
        if self.client is None:
            raise RuntimeError("Gemini is not configured. Set GOOGLE_API_KEY or enable AI_MOCK_MODE=true.")

        from google.genai import types
        response = self.client.models.generate_content(
            model=model,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=schema,
                temperature=0.7,
            ),
        )
        return schema.model_validate_json(response.text)

    def generate_workout(self, username: str, age: int, weight: float, goal: str, intensity: str) -> str:
        if self.settings.ai_mock_mode:
            return self._mock_plan(username, goal, intensity)
        prompt = f"""
Create a safe, practical 7-day fitness plan for:
Name: {username}
Age: {age}
Weight (kg): {weight}
Goal: {goal}
Preferred intensity: {intensity}

Requirements:
- Exactly 7 days.
- Include warm-up, main exercises, sets/reps or duration, rest, and cooldown/recovery.
- Vary training appropriately and include recovery/rest.
- Do not prescribe medical treatment, extreme dieting, or unsafe exercise.
- Keep instructions concise and beginner-friendly unless intensity suggests otherwise.
- Return only data matching the supplied schema.
"""
        result = self._generate(self.settings.workout_model, prompt, WorkoutPlan)
        return result.model_dump_json(indent=2)

    def generate_nutrition_tip(self, goal: str) -> str:
        if self.settings.ai_mock_mode:
            return {
                "weight loss": "Prioritize protein-rich foods, vegetables, whole grains, hydration, and a sustainable calorie deficit rather than extreme restriction.",
                "muscle gain": "Include a protein source in each meal and combine it with enough overall food, carbohydrates, sleep, and progressive resistance training.",
                "flexibility": "Stay hydrated and include a varied diet rich in protein, fruits, vegetables, and micronutrients to support recovery.",
                "general wellness": "Build meals around vegetables or fruit, protein, whole grains, healthy fats, and adequate water; keep routines sustainable.",
            }[goal]

        prompt = f"""
Give one concise, practical nutrition or recovery tip for a person whose fitness goal is "{goal}".
Avoid disease treatment, supplement megadosing, crash diets, or individualized medical claims.
Keep it to 2-4 sentences.
"""
        class Tip(BaseModel):
            tip: str
        return self._generate(self.settings.nutrition_model, prompt, Tip).tip

    def update_workout(self, original_plan: str, feedback: str, goal: str, intensity: str) -> str:
        if self.settings.ai_mock_mode:
            return original_plan + f"\n\nUPDATE REQUEST APPLIED: {feedback}\nGoal: {goal}; Intensity: {intensity}."

        prompt = f"""
Revise the following 7-day fitness plan according to the user's feedback.

Goal: {goal}
Intensity: {intensity}
Feedback: {feedback}

Original plan:
{original_plan}

Keep exactly 7 days, preserve useful parts, apply the feedback where safe,
include warm-up/cooldown and recovery, and return only the supplied schema.
"""
        result = self._generate(self.settings.workout_model, prompt, WorkoutPlan)
        return result.model_dump_json(indent=2)

    @staticmethod
    def _mock_plan(username: str, goal: str, intensity: str) -> str:
        focuses = ["Full body", "Cardio", "Upper body", "Mobility", "Lower body", "Core + cardio", "Recovery"]
        days = []
        for i, focus in enumerate(focuses, 1):
            exercises = [
                Exercise(name="Brisk walk", sets="1", reps_or_duration="10 min", rest="—", notes="Comfortable pace"),
                Exercise(name="Bodyweight squat", sets="3", reps_or_duration="10-12", rest="60 sec"),
                Exercise(name="Incline push-up", sets="3", reps_or_duration="8-12", rest="60 sec"),
            ]
            days.append(WorkoutDay(
                day=f"Day {i}",
                focus=focus,
                warmup="5-10 minutes of easy movement and dynamic mobility.",
                exercises=[e.model_dump() for e in exercises],
                cooldown="5 minutes easy movement plus gentle stretching.",
            ))
        return WorkoutPlan(
            title=f"{username}'s 7-Day {goal.title()} Plan ({intensity.title()} intensity)",
            safety_note="Stop if you feel sharp pain, dizziness, or unusual symptoms. Adapt exercise to your ability and seek professional advice for medical concerns.",
            days=days,
        ).model_dump_json(indent=2)

service = GeminiService()

def generate_workout_gemini(username: str, age: int, weight: float, goal: str, intensity: str) -> str:
    return service.generate_workout(username, age, weight, goal, intensity)

def generate_nutrition_tip_with_flash(goal: str) -> str:
    return service.generate_nutrition_tip(goal)

def update_workout_plan(original_plan: str, feedback: str, goal: str, intensity: str) -> str:
    return service.update_workout(original_plan, feedback, goal, intensity)
