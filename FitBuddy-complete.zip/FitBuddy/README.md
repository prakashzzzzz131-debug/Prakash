# FitBuddy – AI Fitness Plan Generator

FitBuddy is a FastAPI + Jinja2 + SQLite web application that generates personalized 7-day fitness plans, nutrition/recovery tips, and feedback-based plan revisions with Google Gemini.

## What is included

- FastAPI backend and REST endpoints
- Jinja2 HTML frontend
- SQLite + SQLAlchemy persistence
- Gemini workout generation
- Gemini nutrition/recovery tip generation
- Feedback-based plan updates
- Admin dashboard with optional token protection
- API documentation at `/docs`
- Mock AI mode for testing without an API key
- Pytest smoke/integration tests

## Important model update

The supplied project document specified `Gemini 1.5 Pro` and `Gemini Flash`. Those model names are no longer the implementation target used here. This project uses the current Google GenAI Python SDK (`google-genai`) and defaults to the stable `gemini-2.5-pro` for structured workout generation and `gemini-2.5-flash` for fast tips. Google documents both as current 2.5 model endpoints; Google also recommends newer models for new projects as availability changes. Model names can be overridden in `.env`.

Sources:
- https://ai.google.dev/gemini-api/docs/models
- https://ai.google.dev/gemini-api/docs/get-started

## 1. VS Code setup

Install:
- Python 3.11 or newer
- VS Code
- VS Code Python extension

Open the `FitBuddy` folder in VS Code.

### Windows PowerShell

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

## 2. Configure Gemini

Open `.env` and set:

```env
GOOGLE_API_KEY=your_gemini_api_key
AI_MOCK_MODE=false
```

Get a Gemini API key from Google AI Studio.

For testing without Gemini, use:

```env
AI_MOCK_MODE=true
```

Mock mode still exercises the database, routes, templates, and feedback workflow.

## 3. Run

```bash
uvicorn app.main:app --reload
```

Open:

- App: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Admin: http://127.0.0.1:8000/view-all-users

If `ADMIN_TOKEN` is set, append `?token=YOUR_TOKEN` to the admin GET page. The API also accepts `token=YOUR_TOKEN`.

## 4. Test

Run:

```bash
pytest -q
```

The tests enable mock mode automatically and do not require a Gemini key.

## 5. API endpoints

### GET `/health`
Basic health check.

### POST `/generate-workout`
Form fields:
- `username`
- `user_id`
- `age`
- `weight`
- `goal`
- `intensity`

### POST `/submit-feedback`
Form fields:
- `user_id`
- `feedback`

### GET `/api/users`
Returns users and plans. If `ADMIN_TOKEN` is configured, provide the token.

### GET `/api/users/{user_id}`
Returns one user and plans.

### GET `/view-all-users`
Admin HTML dashboard.

### POST `/admin/delete/{user_id}`
Deletes a user and associated plans.

## Architecture

```text
Browser
   |
   v
Jinja2 templates <--> FastAPI routes
                         |
             +-----------+-----------+
             |                       |
             v                       v
        SQLAlchemy/SQLite       GeminiService
                                     |
                          +----------+----------+
                          |                     |
                    Workout model          Flash model
```

## Project tree

```text
FitBuddy/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── database_crud.py
│   ├── models.py
│   ├── routes.py
│   ├── schemas.py
│   ├── services/
│   │   ├── __init__.py
│   │   └── gemini_service.py
│   ├── static/
│   │   └── style.css
│   └── templates/
│       ├── index.html
│       ├── result.html
│       └── all_users.html
├── tests/
│   └── test_app.py
├── .env.example
├── .gitignore
├── README.md
└── requirements.txt
```

## Notes

The application stores original and updated plans separately so the original plan remains available. The documentation's requested functionality is preserved while the Gemini integration uses the modern SDK and structured JSON output for more reliable parsing.

Fitness content is general wellness guidance, not medical diagnosis or treatment. Users should adapt exercise to their abilities and seek qualified professional advice for medical conditions, injuries, or other concerns.
